class CustomData():
    def __init__()